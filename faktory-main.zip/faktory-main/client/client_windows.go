package client

func RssKb() int64 {
	// TODO Submit a PR?
	return 0
}
