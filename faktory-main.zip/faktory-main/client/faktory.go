package client

var (
	Name    = "Faktory"
	Version = "1.9.0"
)
