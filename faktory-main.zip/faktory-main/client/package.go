// Code within this package is licensed according to the MPL found
// in the LICENSE file.

package client
