- Which Faktory package and version?
- Which Faktory worker package and version?
- Please include any relevant worker configuration
- Please include any relevant error messages or stacktraces

Are you using an old version?
Have you checked the changelogs to see if your issue has been fixed in a later version?

https://github.com/contribsys/faktory/blob/master/Changes.md
https://github.com/contribsys/faktory/blob/master/Pro-Changes.md
https://github.com/contribsys/faktory/blob/master/Ent-Changes.md
